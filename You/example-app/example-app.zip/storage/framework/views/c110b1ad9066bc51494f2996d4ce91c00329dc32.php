<h4>Разделы каталога</h4>
<div id="catalog-sidebar">
    <ul>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->parent_id == 0): ?>
            <li>
                <a href="<?php echo e(route('catalog.category', ['slug' => $item->slug])); ?>"><?php echo e($item->name); ?></a>
                <?php if(isset($item->children)): ?>
                    <span class="badge badge-dark">
                        <i class="fa fa-plus"></i> <!-- бейдж с плюсом или минусом -->
                    </span>
                    <ul>
                    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('catalog.category', ['slug' => $child->slug])); ?>">
                                <?php echo e($child->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH D:\OpenServer\domains\FinALPROJECTLARAVEL\You\example-app\resources\views/layout/part/roots.blade.php ENDPATH**/ ?>