

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($brand->name); ?></h1>

    <p><?php echo e($brand->content); ?></p>

    <div class="row">
        <?php $__currentLoopData = $brand->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('catalog.part.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\FinALPROJECTLARAVEL\You\example-app\resources\views/catalog/brand.blade.php ENDPATH**/ ?>