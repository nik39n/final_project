

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h1><?php echo e($product->name); ?></h1>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <img src="https://via.placeholder.com/400x400"
                             alt="" class="img-fluid">
                    </div>
                    <div class="col-md-6">
                        <p>Цена: <?php echo e(number_format($product->price, 2, '.', '')); ?></p>
                        <!-- Форма для добавления товара в корзину -->
                        <form action="<?php echo e(route('basket.add', ['id' => $product->id])); ?>"
                            method="post" class="form-inline">
                            <?php echo csrf_field(); ?>
                            <label for="input-quantity">Количество</label>
                            <input type="text" name="quantity" id="input-quantity" value="1"
                                class="form-control mx-2 w-25">
                            <button type="submit" class="btn btn-success">Добавить в корзину</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <p class="mt-4 mb-0"><?php echo e($product->content); ?></p>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-md-6">
                        <?php if(isset($product->category)): ?>
                        Категория:
                        <a href="<?php echo e(route('catalog.category', ['slug' => $product->category->slug])); ?>">
                            <?php echo e($product->category->name); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 text-right">
                        <?php if(isset($product->brand)): ?>
                        Бренд:
                        <a href="<?php echo e(route('catalog.brand', ['slug' => $product->brand->slug])); ?>">
                            <?php echo e($product->brand->name); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\FinALPROJECTLARAVEL\You\example-app\resources\views/catalog/product.blade.php ENDPATH**/ ?>